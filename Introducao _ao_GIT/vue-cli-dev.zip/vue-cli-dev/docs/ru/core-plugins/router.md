# @vue/cli-plugin-router

> Плагин маршрутизации для vue-cli

## Установка в уже созданный проект

```sh
vue add router
```
