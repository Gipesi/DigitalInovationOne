# Instant Prototyping

Removed in v5. We recommend you to use [vite](https://github.com/vitejs/vite/#readme) for Vue component prototyping.

If you are using `@vue/cli` v4, please visit <https://v4.cli.vuejs.org/guide/prototyping.html> for the documentation.
