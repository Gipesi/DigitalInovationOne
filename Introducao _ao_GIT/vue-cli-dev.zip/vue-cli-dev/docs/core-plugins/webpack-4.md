# @vue/cli-plugin-webpack-4

This plugin provides compatibily for webpack 4 in Vue CLI 5.
