# @vue/cli-init

> `vue init` command addon for `@vue/cli`

This is simply an alias to the old `vue-cli@2.x`.
