module.exports = require('@vue/babel-preset-app')
