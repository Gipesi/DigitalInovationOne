module.exports = {
  // GraphQL directives here
}
