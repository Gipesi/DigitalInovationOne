// Enable mocking in vue.config.js with `"pluginOptions": { "graphqlMock": true }`
// Customize mocking: https://www.apollographql.com/docs/graphql-tools/mocking.html#Customizing-mocks
module.exports = {
  // Mock resolvers here
}
