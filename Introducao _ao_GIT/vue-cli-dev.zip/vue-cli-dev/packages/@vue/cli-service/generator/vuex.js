module.exports = api => {
  require('@vue/cli-plugin-vuex/generator')(api)
}
