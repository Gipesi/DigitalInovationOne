Test project for the React framework, created using [Create React App](https://github.com/facebook/create-react-app).

Can re-generate the project output with
### `npm run build`
