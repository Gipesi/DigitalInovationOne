setInterval(() => {
    let x = 1;
    for (let i = 0; i < 5; i++) {
        x++;   x++;    x++;
    }
}, 0);