document.write("Script.js file"); console.log("Hi");
var a = 1;
var b = 1; fun();

function fun() {
    return true;
}