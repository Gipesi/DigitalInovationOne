document.write("Script2.js file"); console.log("Hi2");
var a = 1;
var b = 1; fun2();

function fun2() {
    return true;
}