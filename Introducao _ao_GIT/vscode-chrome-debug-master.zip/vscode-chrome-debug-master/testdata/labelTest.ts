
export function blubyyb() {

    console.log('hello');
    console.log('hello');
    console.log('hello');
    console.log('hello');
    console.log('hello');
    console.log('world'); // bpLabel: WorldLabel
    console.log('hello'); /* bpLabel: blockLabel */
    console.log('hello');
    console.log('hello');

}