function callbackCaller(cb: Function): void {
    cb();
}
