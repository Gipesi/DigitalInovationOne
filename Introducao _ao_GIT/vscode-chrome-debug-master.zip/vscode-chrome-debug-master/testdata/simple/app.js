function log() {
    console.log('Very simple webpage');
}

log();