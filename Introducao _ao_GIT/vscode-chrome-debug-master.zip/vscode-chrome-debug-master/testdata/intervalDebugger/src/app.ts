function debuggerStatement() {
    debugger;
}

setInterval(debuggerStatement, 100);