---
name: Do not file issues here!
about: VS Code has a new debugger which can be found in the vscode-js-debug repo
title: ''
labels: ''
assignees: ''

---

<!--

**Please read:**

By default, the debug adapter from https://github.com/microsoft/vscode-js-debug is now used for Chrome debugging in VS Code. 

Please file your issue at https://github.com/microsoft/vscode-js-debug/issues

This repo should only be used for high-severity issues involving the old Chrome debugger (when the `debug.javascript.usePreview` setting is disabled).

-->
