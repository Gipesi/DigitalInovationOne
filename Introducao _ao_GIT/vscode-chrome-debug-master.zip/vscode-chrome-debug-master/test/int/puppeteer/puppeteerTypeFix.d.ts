// Needed to make @types/puppeteer pass type checking
// See https://github.com/DefinitelyTyped/DefinitelyTyped/issues/24419

interface Element { }