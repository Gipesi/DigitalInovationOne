export type ManyVariablesPropertiesPrinted = string; // `${variable.name} = ${variable.value} ${(variable.type)}\n`

